package com.example.exampleprojectforrecycleview;

import java.sql.Time;
import java.util.Date;

public class CardData {

    String title;
    String Description;
    String date;
    String time;
    int day;
    String month;

    CardData(String title,
             String Description,
            String date,
            String time, int day, String month)
    {
        this.date=date;
        this.Description=Description;
        this.title=title;
        this.time=time;
        this.day=day;
        this.month=month;
    }
}
