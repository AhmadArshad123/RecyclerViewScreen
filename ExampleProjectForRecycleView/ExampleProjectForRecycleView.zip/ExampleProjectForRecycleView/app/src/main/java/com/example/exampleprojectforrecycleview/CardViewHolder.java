package com.example.exampleprojectforrecycleview;

import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.TextView;

public class CardViewHolder extends RecyclerView.ViewHolder {

    TextView eventName;
    TextView description;
    TextView date;
    TextView time;
    TextView day;
    TextView month;
    View view;

    public CardViewHolder(View itemView) {
        super(itemView);
        eventName=(TextView) itemView.findViewById(R.id.eventName);
        description=(TextView) itemView.findViewById(R.id.description);
        date=(TextView) itemView.findViewById(R.id.eventDate);
        time=(TextView) itemView.findViewById(R.id.eventTime);
        day=(TextView) itemView.findViewById(R.id.day_view);
        month=(TextView) itemView.findViewById(R.id.month_view);
        view=itemView;
    }
}
